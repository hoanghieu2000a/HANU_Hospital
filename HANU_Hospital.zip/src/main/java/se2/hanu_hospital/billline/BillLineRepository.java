package se2.hanu_hospital.billline;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BillLineRepository extends JpaRepository<BillLine, Long> {
}
