package se2.hanu_hospital.util;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
