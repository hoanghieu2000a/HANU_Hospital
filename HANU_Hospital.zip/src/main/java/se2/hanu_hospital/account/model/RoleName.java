package se2.hanu_hospital.account.model;

public enum RoleName {
    ROLE_DOCTOR,
    ROLE_ADMIN,
    ROLE_NURSE,
}
