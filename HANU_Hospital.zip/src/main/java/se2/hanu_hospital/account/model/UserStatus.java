package se2.hanu_hospital.account.model;

public enum UserStatus {
    ACTIVATED,
    DEACTIVATED
}
