package se2.hanu_hospital.medical_procedure;

public class MedicalProcedurePayload {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
