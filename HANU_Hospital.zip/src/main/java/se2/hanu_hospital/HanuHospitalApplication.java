package se2.hanu_hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HanuHospitalApplication {

    public static void main(String[] args) {
        SpringApplication.run(HanuHospitalApplication.class, args);
    }

}
